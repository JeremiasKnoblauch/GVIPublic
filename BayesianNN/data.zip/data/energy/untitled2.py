#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 14 11:57:24 2019

@author: jeremiasknoblauch

Description: Convert xlsx to csv
"""

import xlrd
import csv

def csv_from_excel():
    wb = xlrd.open_workbook('data.xlsx')
    sh = wb.sheet_by_name('1')
    your_csv_file = open('data.csv', 'w')
    wr = csv.writer(your_csv_file, quoting=csv.QUOTE_ALL)

    for rownum in range(sh.nrows):
        wr.writerow(sh.row_values(rownum))

    your_csv_file.close()

# runs the csv_from_excel function:
csv_from_excel()

